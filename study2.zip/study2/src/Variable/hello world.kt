package Variable

fun main (){
    //ini komentar
    /*
    ini juga komentar
     */

    /*
    *ini juga
    * ini juga
    * ini juga
     */

    print("Hello World!")


}