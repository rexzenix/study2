package Variable

fun main (){
    /**
     * convert data type from integer to string or floeat and how to operating them
     */

    //deklarasi variabel
    var angkaPertama : Int = 10
    var masukkanAngka = 13.0

    //konvert tipe data to Int
    angkaPertama = masukkanAngka.toInt()

    //cetak
    print(angkaPertama + 22)
}
