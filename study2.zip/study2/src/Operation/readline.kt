package Operation

fun main () {
    /**
     * input untuk menyimpan data dalam sebuah variabel
     * menggunakan input dari keyboard
     */

    print("Siapa Namamu?")

    val user: String = readln()
    println(user)
}