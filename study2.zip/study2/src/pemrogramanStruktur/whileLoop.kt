package pemrogramanStruktur

fun main (){
    /**
     * contoh sederhana perulangan loop
     */

    //deklarasi variable
    var perhitungan = 9
//melakukan perulangan
    while (perhitungan >= 5){
        println("hitung.... $perhitungan")
        perhitungan--
    }
    println("nilai hitung out of range")
}