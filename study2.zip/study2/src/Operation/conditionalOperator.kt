package Operation

fun main (){
    /**
     * operator untuk pengambilan boolean
     * seperti ( < , > , ==, !=, >=, <=)
     */

    val first = readln()
    val second = readln()

    //mencetak hasil boolean
    println(first > second)
    println(first < second)
    println(first != second)
    println(first == second)
    println(first <= second)
    println(first >= second )
}