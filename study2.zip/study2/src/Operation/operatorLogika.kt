package Operation

    fun main () {
        /**
         * AND OR and NOT
         * && || !
         *
         */

        var first = 2
        val second = 3
        val third = 5

        if ((second < third) && (first < third))println(true) else println(false)
    }