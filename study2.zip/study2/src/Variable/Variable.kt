package Variable

import javax.print.attribute.IntegerSyntax

fun main (){
    //mutable variable
    var Int = 1
    var bilangan:String = "Dua Puluh Enam"
    var angka:Int
    angka = 26

    //Immutable variable
    val nama = "Raka"

    println("$Int $nama $bilangan $angka")

}